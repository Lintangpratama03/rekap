###################
BUILD NOTES : 
###################
| 
| Codeigniter 3.1.13
| Bootstrap 5.2.3
| Check on PHP 8.1.X (PHP version 5.6 or newer is recommended)
| 
###################
HOW TO PUBLISH / TESTING LOKAL : 
###################
| 
| Install Webserver, e.g XAMPP 
| copas semua file ini kedalam httdocs webserver
| Run webserver 
| open "localhost/inkelud-ci" di web browser
| 
| POSTMAN Collection bisa didownload di : https://trello.com/c/2BHRUmUB
| 
###################
HOW TO PUBLISH PRODUCTION : 
###################
| 
| Buka inkelud-ci/application/config
| ganti base_url ke "https://nama_domain.com/"
