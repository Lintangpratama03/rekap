<div id="navbar-wrapper">
    <nav class="navbar navbar-inverse">
        <div class="container-fluid">
            <div class="navbar-header">
                <a href="#" class="navbar-brand" id="sidebar-toggle"><i class="fa fa-bars"></i></a>
            </div>
            <div class="navbar-item">
                <a href="#" class="navbar-brand capitalize" id="currentTime"></a>
            </div>
            <div class="navbar-item">
                <a href="#" class="navbar-brand capitalize" id="userDataName">Halo <?php echo $this->session->userdata('user_name'); ?></a>
            </div>
        </div>
    </nav>
</div>