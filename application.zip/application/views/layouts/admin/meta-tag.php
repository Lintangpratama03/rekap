<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=1920">
<meta name="description" content="In Kelud - Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repellat assumenda, qui dolorem ea officia similique dignissimos nisi omnis, debitis nulla dolorum ratione voluptatem quo perferendis. Harum quam est dignissimos iure.">
<meta name="author" content="rahman">
<meta name="theme-color" content="#001822">

<title><?php echo $title; ?></title>
<link rel="icon" href="<?php echo base_url(); ?>assets/img/main/logo-plain-dp2kbp3a-kab-kediri.png" type="image/x-icon">
<meta property="og:url" content="<?php echo base_url(); ?>" />
<meta property="og:image" content="<?php echo base_url(); ?>assets/img/main/logo-dp2kbp3a-kab-kediri.png" />
<meta property="og:type" content="article" />
<meta property="og:title" content="In Kelud - Sistem Ke dan Lud" />
<meta property="og:description" content="In Kelud - Lorem ipsum dolor sit amet consectetur, adipisicing elit. Repellat assumenda, qui dolorem ea officia similique dignissimos nisi omnis, debitis nulla dolorum ratione voluptatem quo perferendis. Harum quam est dignissimos iure." />
<meta property="og:site_name" content="sikelud.go.id" />
<link rel='canonical' href='https://sikelud.go.id/' />