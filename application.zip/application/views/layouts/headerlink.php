<!-- <link href="<?php echo base_url(); ?>assets/css/bootstrap.css" rel="stylesheet"> -->


<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css" />
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.14.0-beta2/css/bootstrap-select.min.css" />

<link href="<?php echo base_url(); ?>assets/css/custom_style.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/admin_custom_style.css" rel="stylesheet">
<link href="<?php echo base_url(); ?>assets/css/font-awesome/all.min.css" rel="stylesheet">
<link href="https://cdn.datatables.net/1.13.6/css/jquery.dataTables.min.css" rel="stylesheet">